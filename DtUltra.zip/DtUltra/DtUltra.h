#ifndef DtUltra_h
#define DtUltra_h

#include "Arduino.h"

class DtUltra{
  public:
    String setPin(int trigPin, int echoPin);
    //String setPinms(int trigPin, int echoPin);
    int Distance(int trigPin, int echoPin);
  private:
    int _trigPin, _echoPin;
};
#endif
