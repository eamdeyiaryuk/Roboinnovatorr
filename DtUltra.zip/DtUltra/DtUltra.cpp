#include "DtUltra.h"
String DtUltra::setPin(int trigPin, int echoPin){
  _trigPin = trigPin;
  _echoPin = echoPin;
  pinMode(_trigPin, OUTPUT);
  pinMode(_echoPin, INPUT);
}
int DtUltra::Distance(int trigPin, int echoPin){
   _trigPin = trigPin;
   _echoPin = echoPin;
   int distance;
   long duration;
   int timer1,timer2;
  if(millis() - timer1 >= 0.002) // Sets the trigPin HIGH (ACTIVE) for 10 microseconds
  {
    digitalWrite(trigPin, LOW);
    timer1 = millis();
  }
  if(millis() - timer2 >= 0.01)
  {
    digitalWrite(trigPin, HIGH);
    timer2 = millis();
  }
  digitalWrite(trigPin, LOW);
  duration = pulseIn(echoPin, HIGH);
  return distance = duration * 0.034 /2;
}
